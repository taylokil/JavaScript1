console.log("Kile Taylor");
console.log("1997");
console.log(1997);
console.log("Kile", "Taylor", "(1997)");
console.log("Kile");
console.log("Taylor");
console.log(1997);
console.log("Kile" + "Taylor" + "(1997)");
console.log("Kile" , "Taylor" , "(1997)");
